DarkSkies SkinGate — one-time install (NOMM)

1. Install BepInEx via NOMM if needed.
2. Import the SkinGate zip in NOMM → Install → enable.

You do not need allowlist.json on your PC. When you join the host's game,
SkinGate pulls the allowlist from the host automatically.

The host admin runs Discord /sync-skins and presses F11 if the game is open.
