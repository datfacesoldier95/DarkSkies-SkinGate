DarkSkies SkinGate 1.1.0 — install once (host and all joiners)

1. Install BepInEx via NOMM if needed.
2. Import SkinGate-1.1.0.zip in NOMM → Install → enable.

You do NOT need allowlist.json on client PCs.
The host runs Discord /sync-skins, then hosts a session.
Clients receive the allowlist from the host automatically.

Check BepInEx\LogOutput.log for:
  SkinGate SYNC recv … hash=…
  SkinGate SYNC ack … (on the host)

Host: press F11 after /sync-skins if the game is already open.
