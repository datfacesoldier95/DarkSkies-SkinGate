DarkSkies SkinGate — squad install (NOMM)

1. Install BepInEx via NOMM if you do not have it yet.
2. In NOMM: add this zip (Downloads → Import from file, or drop into your NOMM downloads folder → Install).
3. Enable the mod and deploy / link to the game.
4. After the admin runs Discord /sync-skins, replace allowlist.json in your SkinGate plugin folder
   (same folder as SkinGate.dll) with the new file they send, then press F11 in-game.

Requires Steam workshop subscription for squad skins listed in allowlist.json.
